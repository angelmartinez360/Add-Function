import UIKit

var str = "Hello, playground"

func addNum(num1: Int, num2: Int) -> Int {
    var total = 0
    total = num1 + num2
    return total
}

var totalNumber = addNum (num1: 3 , num2: 8)
var t2 = addNum(num1:5, num2: 12 )
print (totalNumber)
